#!/usr/bin/env node
/**
 * Simple icon generator
 * Requires: npm install canvas
 * Or: Generate manually with your design tool and save as .png
 */

const fs = require('fs');
const path = require('path');

// For GitHub Pages deployment, you can also:
// 1. Export icons from your design tool (Figma, Adobe, etc.)
// 2. Use online PNG generator
// 3. Run this script locally with canvas installed

console.log(`
Icon Generator Helper
======================

To create the icon files, choose one of these options:

1. USE ONLINE TOOL (easiest):
   - Visit https://favicon-generator.org/
   - Upload a 512x512 PNG or SVG
   - Download icon files
   - Place icon-192.png, icon-512.png, icon-outline.png, icon-color.png in this directory

2. USE NODEJS WITH CANVAS:
   npm install canvas
   node build-icons.js --generate

3. DESIGN MANUALLY:
   - Create 192x192 and 512x512 PNG files
   - Name them icon-192.png, icon-512.png
   - Create icon-outline.png and icon-color.png for Teams

4. USE GITHUB WORKFLOW:
   - The icons will be auto-generated on deployment if you install 'canvas'

PLACEHOLDER: Creating stub files for testing...
`);

const stubPNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');

const files = ['icon-192.png', 'icon-512.png', 'icon-outline.png', 'icon-color.png'];
files.forEach(f => {
  if (!fs.existsSync(path.join(__dirname, f))) {
    fs.writeFileSync(path.join(__dirname, f), stubPNG);
    console.log(`✓ Created stub: ${f}`);
  }
});

console.log(`\nStub icons created. Replace them with real PNG files before production.`);
