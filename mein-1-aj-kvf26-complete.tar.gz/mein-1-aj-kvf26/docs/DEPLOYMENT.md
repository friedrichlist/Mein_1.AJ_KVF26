# Deployment-Anleitung für GitHub Pages + Teams

## Was ist fertig?

✅ **PWA-App** (iOS Home-Screen, Android, Browser)  
✅ **Service Worker** (Offline-fähig)  
✅ **Teams-App-Paket** (mein-jahr-kvf26.zip)  
✅ **Dokumentation** (README, Quickstart, Teams-Setup)  
✅ **QR-Code** (für Schüler)  

---

## Schritt-für-Schritt: Vom Laptop zu GitHub

### 1. Diesen Ordner zu GitHub hochladen

**Mit GitHub Desktop (einfach):**
```
1. Öffne GitHub Desktop
2. File → Clone Repository
3. URL: https://github.com/NEW_REPO_URL_AFTER_CREATING
4. Clone
5. Kopiere alle Dateien aus diesem Ordner hinein
6. Commit & Publish
```

**Mit Git-Befehlszeile:**
```bash
# 1. Neues Repo auf GitHub erstellen (Web):
#    https://github.com/new
#    Name: Mein-1-AJ-KVF26
#    Public
#    Create

# 2. Lokal
cd ~/Desktop
git clone https://github.com/schiggii-maker/Mein-1-AJ-KVF26.git
cd Mein-1-AJ-KVF26

# 3. Alle Dateien aus diesem Ordner kopieren hier hin

# 4. Hochladen
git add .
git commit -m "Initial commit: Mein Jahr app"
git push origin main
```

### 2. GitHub Pages aktivieren

1. Gehe zu: https://github.com/schiggii-maker/Mein-1-AJ-KVF26
2. Settings → Pages
3. Branch: **main** (root)
4. Save → grüner Haken ✅
5. Nach 1-2 Min: App lädt unter https://schiggii-maker.github.io/Mein-1-AJ-KVF26

### 3. QR-Code & Link für Klasse

**Link:**
```
https://schiggii-maker.github.io/Mein-1-AJ-KVF26
```

**QR-Code:** Siehe `docs/qr-code.png` (oder neu generieren bei Bedarf)

**Drucken & verteilen** oder **in Teams posten**

---

## Für IT-Admin: Teams-App einrichten

1. Öffne `mein-jahr-kvf26.zip` (ist schon fertig)
2. Oder: Neu machen:
   ```bash
   cd Mein-1-AJ-KVF26
   zip -j mein-jahr-kvf26.zip teams-manifest.json icon-outline.png icon-color.png
   ```

3. Teams Admin Center:
   - https://admin.teams.microsoft.com
   - Teams Apps → Manage apps
   - Upload an app → mein-jahr-kvf26.zip
   - Review, genehmigen, publizieren

4. Im Klassen-Team verfügbar machen

Siehe: `docs/TEAMS-SETUP.md` für Details

---

## Dateien-Übersicht

```
Mein-1-AJ-KVF26/
├── index.html                  ← Die komplette App
├── manifest.json               ← PWA-Config (Home-Screen)
├── service-worker.js           ← Offline-Cache
├── teams-manifest.json         ← Teams-Config
├── icon-*.png                  ← Icons (192×512, Outline, Color)
├── mein-jahr-kvf26.zip         ← Fertig für Teams Upload
├── README.md                   ← Dokumentation für Schüler
├── .github/workflows/deploy.yml ← Auto-Deploy (optional)
├── .gitignore
└── docs/
    ├── QUICKSTART.md           ← 5-Minuten-Setup
    ├── TEAMS-SETUP.md          ← Für IT-Admin
    ├── DEPLOYMENT.md           ← Diese Datei
    └── qr-code.png             ← QR-Code zum Scannen
```

---

## Nach dem Deploy: Änderungen machen

Beispiel: Text in der App ändern

```bash
# 1. Datei bearbeiten (z.B. index.html)
# 2. Speichern
# 3. Commit & Push
git add index.html
git commit -m "Update datenschutz text"
git push origin main

# 4. Nach ~1 Min ist es live
```

Die Schüler müssen nur den Browser neu laden (oder App neu öffnen) — das ist alles!

---

## Sicherheit & Datenschutz (Info für Eltern/Schulleitung)

✅ **Lokal:** Alle Daten bleiben auf dem Schüler-Gerät  
✅ **Offline:** Funktioniert ohne Internet nach dem ersten Laden  
✅ **Verschlüsselt:** GitHub Pages ist HTTPS  
✅ **Keine Accounts:** Keine Anmeldung, keine Tracking  
✅ **Export:** Schüler können jederzeit exportieren  

⚠️ **Wichtig:** Wenn das Gerät gelöscht wird, sind die Daten weg. Export wird empfohlen.

---

## Troubleshooting

| Problem | Lösung |
|---------|--------|
| App lädt nicht | Warte 2 Min nach Push, Cache löschen |
| GitHub Pages nicht aktiv | Settings → Pages: Branch = main, Save |
| Icons sehen komisch aus | Sind Stubs, später mit echten PNGs ersetzen |
| In Teams nicht zu finden | IT-Admin muss ZIP hochladen & genehmigen |
| Daten weg nach Reinstall | Normal, Export vorher machen |

---

**Fertig! Die App ist einsatzbereit. Viel Spaß! 🚀**
