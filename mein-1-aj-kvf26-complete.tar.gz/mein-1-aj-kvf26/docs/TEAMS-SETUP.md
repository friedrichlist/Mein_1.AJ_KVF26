# Teams-App Setup für IT-Admin

## Schritt 1: Vorbereitung

- [ ] GitHub-Repo ist öffentlich und GitHub Pages ist aktiviert
- [ ] Die App ist erreichbar unter: `https://schiggii-maker.github.io/Mein-1-AJ-KVF26`
- [ ] Icons sind erstellt oder Stubs sind OK (sehen nicht so schön aus, funktionieren aber)

## Schritt 2: Teams Manifest anpassen

Bearbeite `teams-manifest.json`:

```json
{
  "id": "UNIQUE-UUID-HIER-EINFUGEN",  // z.B. 12345678-1234-1234-1234-123456789012
  "packageName": "de.schule.meinjahrkvf26",  // Eindeutiger Name
  "developer": {
    "name": "Deine Schule",
    "websiteUrl": "https://deine-schule.de",
    "privacyUrl": "https://deine-schule.de/datenschutz",
    "termsOfUseUrl": "https://deine-schule.de/nutzungsbedingungen"
  },
  "validDomains": [
    "schiggii-maker.github.io"  // oder deine Custom Domain, wenn vorhanden
  ]
}
```

## Schritt 3: ZIP-Paket erstellen

```bash
zip -j mein-jahr-kvf26.zip teams-manifest.json icon-outline.png icon-color.png
```

Die ZIP muss enthalten:
- `teams-manifest.json`
- `icon-outline.png` (192×192, einfarbig für Outline)
- `icon-color.png` (192×192, farbig)

## Schritt 4: Im Teams Admin Center hochladen

1. **Microsoft Teams Admin Center öffnen:**
   - https://admin.teams.microsoft.com/

2. **Zu Apps → "Verwalten von Apps" navigieren**
   - Teams Apps → Manage apps → Upload an app

3. **ZIP-Datei hochladen**
   - Datei: `mein-jahr-kvf26.zip`

4. **Überprüfung & Genehmigung**
   - App wird überprüft (Name, Icons, Manifest)
   - Für die Organisation genehmigen

5. **Verfügbar machen:**
   - Nach Genehmigung können Benutzer die App suchen
   - Oder: Im Team automatisch hinzufügen

## Schritt 5: Im Klassen-Team einbinden

**Option A: Benutzer suchen selbst**
- Teams App öffnen → "More apps" (+) → Nach "Mein Jahr" suchen
- "Zum Team hinzufügen" oder "Personal App"

**Option B: Von IT auto-installiert**
- Im Teams Admin Center kann man Apps im Tenant org-weit pushen
- Dann automatisch im Team sichtbar

## Datenschutz & Sicherheit

✅ **Lokal & offline:** Daten verlassen das Gerät nicht  
✅ **HTTPS-only:** GitHub Pages ist automatisch verschlüsselt  
✅ **Kein Backend:** Nur statische Dateien, kein Server  
✅ **Export-Funktion:** Benutzer können jederzeit ihre Daten exportieren  

## Troubleshooting

### "Ungültiges Manifest"
- Prüfe: JSON-Syntax (keine Fehler?)
- Prüfe: `id` und `packageName` sind eindeutig
- Prüfe: `validDomains` stimmt mit der App-URL überein

### "Icons zu klein"
- 192×192 Pixel erforderlich
- PNG-Format
- Outline sollte einfarbig sein (z.B. schwarz auf transparent)
- Color kann farbig sein

### "App antwortet nicht"
- Prüfe: GitHub Pages läuft (`https://...` zeigt HTML-Content)
- Prüfe: CORS ist nicht blockiert (GitHub Pages erlaubt das)
- Prüfe: Browser-Konsole auf Fehler checken

### "Nur bestimmte Benutzer sehen die App"
- Benutzergruppen/Rollen-basierter Zugriff im Teams Admin Center konfigurieren
- Oder: App ist nur als "Personal" verfügbar, nicht im Team

---

## Häufige Fragen

**Q: Können Schüler ihre Daten sichern?**
A: Ja, es gibt einen Export-Dialog in der App. Sie können ihre Einträge als Text exportieren.

**Q: Was passiert mit den Daten, wenn das Gerät gelöscht wird?**
A: Die Daten sind weg (localStorage wird gelöscht). Das ist normal für Web-Apps ohne Cloud-Sync.

**Q: Kann man Daten zwischen Geräten synchronisieren?**
A: Nein, aktuell nicht. Das würde ein Backend erfordern. Die App ist bewusst lokal-only.

**Q: Kann die Schule die Einträge einsehen?**
A: Nein. Die App speichert lokal, es gibt keinen Server. Nur der Schüler selbst kann seine Einträge sehen.

---

## Support

Bei Fragen oder Bugs: 
- GitHub Issue öffnen: https://github.com/schiggii-maker/Mein-1-AJ-KVF26/issues
- Oder: Microsoft Teams Support

---

**Viel Spaß mit der App! 📱**
