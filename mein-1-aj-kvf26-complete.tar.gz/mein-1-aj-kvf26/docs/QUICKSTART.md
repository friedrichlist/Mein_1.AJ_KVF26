# Quickstart — App in 5 Minuten deployen

## 1. GitHub Repo erstellen

```bash
# In deinem GitHub Account (schiggii-maker):
# Neu repo: "Mein-1-AJ-KVF26"
# Öffentlich (public)
# License: MIT (optional)

# Lokal:
git clone https://github.com/schiggii-maker/Mein-1-AJ-KVF26.git
cd Mein-1-AJ-KVF26
```

## 2. App-Dateien hochladen

```bash
# Alle Dateien aus diesem Ordner ins Repo:
# - index.html
# - manifest.json
# - service-worker.js
# - teams-manifest.json
# - icon-*.png
# - README.md
# - .github/workflows/deploy.yml (optional, automatischer Deploy)

git add .
git commit -m "Add Mein Jahr app"
git push origin main
```

## 3. GitHub Pages einschalten

```
Repo → Settings → Pages
  Branch: main (root)
  Save
```

Warten 1–2 Minuten → fertig! 🎉

Die App ist jetzt verfügbar unter:
```
https://schiggii-maker.github.io/Mein-1-AJ-KVF26
```

## 4. Schülern verteilen (PWA)

### iPhone:
1. Safari → Link öffnen
2. Share → "Zum Home-Bildschirm"
3. Done

### Android:
1. Chrome → Link öffnen
2. Menu (⋮) → "Zum Home-Bildschirm hinzufügen"
3. Done

### QR-Code für die Klasse:
Siehe `docs/qr-code.png` oder generier neu:
```
https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=https://schiggii-maker.github.io/Mein-1-AJ-KVF26
```

## 5. Teams-App (optional, aber empfohlen)

Für die IT-Admin der Schule:

```bash
# Manifest anpassen (teams-manifest.json)
# Dann:
zip -j mein-jahr-kvf26.zip teams-manifest.json icon-outline.png icon-color.png

# Teams Admin Center:
# https://admin.teams.microsoft.com
# → Teams Apps → Upload an app
# → mein-jahr-kvf26.zip
# → Review & publish
```

Siehe: `docs/TEAMS-SETUP.md` für Details

---

## Änderungen machen

Wenn du etwas ändern möchtest:

1. `index.html` bearbeiten
2. Commit & Push
3. Warten 1 Min → auf GitHub Pages live

```bash
# Beispiel: Text in der App ändern
# Bearbeite index.html, z.B. die Datenschutz-Text im <div class="privat">

git add index.html
git commit -m "Update privacy text"
git push origin main
```

---

## Troubleshooting

**App lädt nicht?**
- Warte 2 Min nach dem ersten Push
- Cache löschen: Ctrl+Shift+Del
- Prüfe: ist GitHub Pages an? (Settings → Pages → green checkmark?)

**Im Browser OK, aber Home-Bildschirm-Icon funktioniert nicht?**
- Das ist normal wenn du nicht 2 Min wartest
- Cache in Safari/Chrome löschen
- Noch mal versuchen

**Teams-App nicht zu finden?**
- IT-Admin muss die ZIP hochladen & genehmigen
- Danach 5–10 Min warten
- Dann: Team → Apps → Nach "Mein Jahr" suchen

---

## Das war's!

Die App läuft jetzt auf:
- ✅ iPhone (Home-Bildschirm)
- ✅ Android (Home-Bildschirm)
- ✅ Desktop/Laptop (Browser)
- ✅ Microsoft Teams (wenn IT hochgeladen hat)

**Viel Spaß! 🎉**

---

Fragen? → README.md lesen oder GitHub Issue öffnen
