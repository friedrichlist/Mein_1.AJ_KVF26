# Mein Jahr · KVF 26

**Persönliches Jahresprotokoll** – eine Offline-App für das erste Ausbildungsjahr.

- 📱 Funktioniert auf iPhone, Android, Desktop
- 🔒 Datenschutz: Alles bleibt auf deinem Gerät
- 📵 Offline: Nach dem ersten Laden brauchst du kein Internet mehr
- 🔄 Datensicherung: Exportiere/importiere deine Einträge

---

## Für Schüler:innen

### Option 1: Zum Home-Bildschirm hinzufügen (PWA)

**iPhone:**
1. Safari öffnen → diese URL: `https://schiggii-maker.github.io/Mein-1-AJ-KVF26`
2. Teilen-Button → „Zum Home-Bildschirm"
3. Fertig – die App startet jetzt wie eine normale App

**Android:**
1. Chrome öffnen → diese URL: `https://schiggii-maker.github.io/Mein-1-AJ-KVF26`
2. Menu (⋮) → „Zum Home-Bildschirm hinzufügen"
3. Fertig

### Option 2: In Microsoft Teams (Klassen-Team)

Dein Lehrer/deine Lehrerin fügt die App ins Klassen-Team ein — dann erscheint **Mein Jahr** oben in der App-Leiste.

---

## Für Lehrkräfte / IT-Admin

### Schritt 1: GitHub Pages aktivieren

```bash
# Das Repo ist bereits bereit für GitHub Pages
# Gehe zu: Repo Settings → Pages
# Wähle: Branch "main" → Speichern
# Nach 1–2 Minuten ist die App erreichbar unter:
# https://schiggii-maker.github.io/Mein-1-AJ-KVF26
```

### Schritt 2: Icons erstellen (optional, aber empfohlen)

Die Stub-Icons sind einfach grau. Für ein schöneres Aussehen:

1. **Online-Tool:** https://favicon-generator.org/
   - Ein Design hochladen oder aus Vorlage bauen
   - PNG-Icons (192×192 + 512×512) herunterladen
   - In dieses Repo upload

2. **Manuell:**
   - `icon-192.png` (192×192 Pixel)
   - `icon-512.png` (512×512 Pixel)
   - `icon-outline.png` (für Teams, 192×192, einfarbig)
   - `icon-color.png` (für Teams, 192×192, farbig)

### Schritt 3: Teams-App hochladen

Für IT-Admins der Schule (eurer Microsoft 365 Tenant):

1. **ZIP-Paket erstellen:**
   ```bash
   zip -r mein-jahr-kvf26.zip teams-manifest.json icon-outline.png icon-color.png
   ```

2. **Teams Admin Center:**
   - Gehe zu: Teams Admin Center → Teams Apps → Verwalten von Apps
   - Hochladen → Diese Datei: `mein-jahr-kvf26.zip`
   - Review & veröffentlichen für die Organisation

3. **Im Klassen-Team verfügbar machen:**
   - Im Team: Mehr apps (+) → Nach "Mein Jahr" suchen
   - Zum Team hinzufügen

---

## Technisch

### Dateien

- `index.html` – Die komplette App (365 Tage, Notizen, Datenschutz)
- `manifest.json` – PWA-Konfiguration (Home-Bildschirm, Icons, Offline)
- `service-worker.js` – Offline-Cache (funktioniert auch ohne Internet)
- `teams-manifest.json` – Teams-App-Konfiguration
- `build-icons.js` – Helper zum Generieren von Icons

### Funktionen

- **Offline-First:** Service Worker cached alles nach dem ersten Besuch
- **localStorage:** Daten werden lokal auf dem Gerät gespeichert (kein Server)
- **Sicherung:** Im Dialog unten kannst du exportieren/importieren
- **Teams:** Lädt auch im Teams-Kontext, nutzt Teams-JS-SDK

### Deployment

```bash
# 1. In dein GitHub-Repo pushen
git add .
git commit -m "Add Mein Jahr app"
git push origin main

# 2. GitHub Pages einschalten (Settings → Pages → main branch)
# 3. Warten auf Deploy (grünes Häkchen bei Commit)
# 4. App ist erreichbar unter: https://dein-username.github.io/Mein-1-AJ-KVF26
```

---

## Datenschutz & Sicherheit

✅ **Keine Datenübertragung:** Alles bleibt auf dem Gerät  
✅ **Kein Server-Backend:** Nur statische Dateien (HTML/CSS/JS)  
✅ **HTTPS:** GitHub Pages ist automatisch verschlüsselt  
✅ **Offline:** Funktioniert komplett ohne Internet  

⚠️ **Wichtig:** Wenn Schüler:innen ihr Gerät löschen/zurücksetzen, sind die Einträge weg (außer exportiert). Der Sicherungs-Dialog ermöglicht Export als Text-File.

---

## Troubleshooting

**App lädt nicht?**
- GitHub Pages braucht 1–2 Min nach dem ersten Push
- Prüfe: Settings → Pages → ist "main" branch ausgewählt?
- Versuche: Cache löschen (Ctrl+Shift+Del / Cmd+Shift+Delete)

**Daten weg nach Neuinstall?**
- Das ist normal – localStorage wird gelöscht
- Nutze den Sicherungs-Dialog zum Exportieren vor dem Löschen

**In Teams nicht zu finden?**
- IT-Admin muss die ZIP ins Teams Admin Center hochladen
- Warte auf Review/Veröffentlichung
- Dann: Team → App hinzufügen → Nach "Mein Jahr" suchen

---

## Kontakt & Support

Bei Fragen oder Bugs: Schreib eine Nachricht in Teams oder öffne ein Issue im GitHub-Repo.

---

**Made with ❤️ for KVF 26**
